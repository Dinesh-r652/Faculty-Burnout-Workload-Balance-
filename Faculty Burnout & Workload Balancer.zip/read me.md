# Faculty Burnout & Workload Balancer

An AI/ML-based system that analyzes faculty workload and predicts **burnout risk** based on teaching, advising, committee responsibilities, research, administrative work, semester progress, and historical leave days.

## 📌 Project Overview

Faculty members often handle multiple responsibilities at the same time. Uneven workload distribution can increase work pressure and may contribute to burnout.

The **Faculty Burnout & Workload Balancer** uses a Machine Learning model to analyze faculty workload factors and classify the expected burnout risk into:

* 🟢 Low
* 🟡 Medium
* 🔴 High

The project also provides a **Flask REST API** that allows applications to send faculty workload data and receive burnout predictions with probability scores.

---

## 🎯 Objectives

* Analyze faculty workload across multiple responsibilities.
* Identify workload and pressure-related patterns.
* Predict faculty burnout risk using Machine Learning.
* Provide probability scores for each burnout-risk category.
* Expose the trained model through a Flask REST API.
* Support future integration with web or frontend applications.

---

## 🏗️ System Architecture

```text
Faculty Workload Data
        │
        ▼
Synthetic Dataset Generation
        │
        ▼
Data Preprocessing
(Imputation + Scaling)
        │
        ▼
Random Forest Classifier
        │
        ▼
Burnout Risk Prediction
 ┌──────┼──────┐
 ▼      ▼      ▼
Low   Medium  High
        │
        ▼
     Flask API
        │
        ▼
 /predict Endpoint
        │
        ▼
Prediction + Probabilities
```

---

## 📊 Input Features

The model uses the following seven features:

| Feature                 | Description                        |
| ----------------------- | ---------------------------------- |
| `Teaching_Hours`        | Number of hours spent on teaching  |
| `Advising_Students`     | Number of students advised         |
| `Committee_Count`       | Number of committees handled       |
| `Research_Hours`        | Hours spent on research            |
| `Admin_Hours`           | Hours spent on administrative work |
| `Semester_Progress`     | Progress of the current semester   |
| `Historical_Leave_Days` | Previous leave days                |

---

## 🤖 Machine Learning Model

### Algorithm

**Random Forest Classifier**

The model is trained to classify burnout risk into:

```text
Low
Medium
High
```

### Model Configuration

```text
n_estimators = 150
max_depth = 8
random_state = 42
class_weight = balanced
```

### Preprocessing

The machine learning pipeline includes:

1. **Median Imputation**

   * Handles missing numerical values.

2. **Standard Scaling**

   * Scales numerical features before model prediction.

3. **Random Forest Classification**

   * Predicts the burnout-risk category.

The complete trained pipeline is saved as:

```text
faculty_burnout_model_pipeline.pkl
```

---

## 📁 Project Structure

```text
Faculty-Burnout-Workload-Balancer/
│
├── Notebook_1_Dataset_Generation.ipynb
├── Notebook_2_Model_Training.ipynb
├── Notebook_3_Model_Testing.ipynb
├── Notebook_4_Flask_API.ipynb
│
├── faculty_workload_dataset.csv
├── faculty_burnout_model_pipeline.pkl
│
├── README.md
└── requirements.txt
```

---

# 🚀 Flask API

The trained ML pipeline is integrated with a Flask REST API.

### Base URL

For local/Colab testing:

```text
http://127.0.0.1:8001
```

---

## 1. Home Endpoint

### Request

```http
GET /
```

### Purpose

Checks whether the Flask API is running.

### Example Response

```json
{
    "message": "Faculty Burnout & Workload Balancer API is running",
    "status": "success"
}
```

---

## 2. Burnout Prediction Endpoint

### Request

```http
POST /predict
```

### Example Input

```json
{
    "Teaching_Hours": 20,
    "Advising_Students": 10,
    "Committee_Count": 2,
    "Research_Hours": 10,
    "Admin_Hours": 5,
    "Semester_Progress": 0.7,
    "Historical_Leave_Days": 3
}
```

### Example Response

```json
{
    "predicted_burnout_risk": "Low",
    "risk_probabilities": {
        "High": 0.0,
        "Low": 0.5351,
        "Medium": 0.4649
    }
}
```

> The prediction and probability values depend on the trained model and input data.

---

# 🧪 API Testing

The Flask API was tested using Python's `requests` library.

### Normal Workload Test

```text
Status Code: 200
Prediction: Low
```

### High Workload Test

A high workload scenario was also tested using higher teaching, advising, committee, administrative, semester-progress, and historical-leave values.

### Invalid Input Test

The API checks whether all required fields are provided.

Example:

```json
{
    "Teaching_Hours": 20,
    "Advising_Students": 10
}
```

Expected response:

```text
Status Code: 400
```

with an error indicating the missing required field.

---

# 🛠️ Technologies Used

| Technology    | Purpose                         |
| ------------- | ------------------------------- |
| Python        | Main programming language       |
| Pandas        | Data handling                   |
| NumPy         | Numerical operations            |
| Scikit-learn  | Machine Learning                |
| Random Forest | Burnout-risk classification     |
| Joblib        | Model saving/loading            |
| Flask         | REST API development            |
| Requests      | API testing                     |
| Google Colab  | Development and experimentation |

---

# 📓 Notebook Workflow

## Notebook 1 — Dataset Generation

Creates the faculty workload dataset containing:

* Teaching workload
* Advising workload
* Committee responsibilities
* Research workload
* Administrative workload
* Semester progress
* Historical leave information

Output:

```text
faculty_workload_dataset.csv
```

---

## Notebook 2 — Model Training

Steps:

```text
Load Dataset
     ↓
Select Features
     ↓
Train/Test Split
     ↓
Preprocessing
     ↓
Random Forest Training
     ↓
Model Evaluation
     ↓
Save Pipeline
```

Output:

```text
faculty_burnout_model_pipeline.pkl
```

---

## Notebook 3 — Model Testing

Loads the saved ML pipeline and performs predictions on new faculty workload data.

It also displays the probability of each burnout-risk class.

---

## Notebook 4 — Flask API Integration

Loads the trained pipeline and exposes it through REST API endpoints.

```text
GET  /
POST /predict
```

This allows other applications to communicate with the ML model.

---

# ⚙️ Installation

Clone the repository:

```bash
git clone <your-github-repository-url>
cd Faculty-Burnout-Workload-Balancer
```

Install the required packages:

```bash
pip install flask requests pandas numpy scikit-learn joblib
```

---

# ▶️ Running the Flask API

Run the Flask application:

```python
app.run(
    host="0.0.0.0",
    port=8001,
    debug=False,
    use_reloader=False
)
```

The API will be available at:

```text
http://127.0.0.1:8001
```

---

# 🔍 Example Prediction Flow

```text
Faculty Workload Information
          │
          ▼
      POST /predict
          │
          ▼
    Flask receives JSON
          │
          ▼
 Convert input to DataFrame
          │
          ▼
 ML Pipeline Preprocessing
          │
          ▼
 Random Forest Classifier
          │
          ▼
   Burnout Risk Prediction
          │
          ▼
JSON Response
```

---

# ⚠️ Important Note

This project is an **AI/ML research and workload-analysis prototype**. Burnout-risk predictions should not be treated as medical diagnoses or definitive assessments of an individual faculty member.

The current dataset is synthetic and is intended for development, testing, and demonstration purposes.

---

# 🔮 Future Enhancements

* Develop a web-based dashboard for administrators.
* Add faculty workload visualization.
* Add workload balancing recommendations.
* Integrate historical workload trends.
* Add database support.
* Add authentication and authorization.
* Deploy the Flask API to a cloud platform.
* Connect the API with a React frontend.
* Add explainable AI techniques to show why a prediction was generated.
* Use real-world anonymized institutional data for further validation.

---

# 👨‍💻 Author

**Dinesh R**

Faculty Lifecycle & Research Intelligence Project

---

## 📜 License

This project is intended for educational, research, and demonstration purposes.
